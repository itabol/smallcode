import React, { Component } from 'react';

{/* Small React Component - itamar   */}

const panelStyle = {
	  height:"40px",
	  fontSize:"24px",
	  marginTop:"30px",
	  width:"100%",
	  textAlign:"center"
}

const canvasStyle = {
	  backgroundColor: "black",
	  width:"100%",
	  height:"500px"
}


class Colp extends Component {
	
	constructor(props) {
	super(props);
		this.state = { canvaName: "myCanvas" };
	}
	
	colorPattern(){
		return document.getElementById("mycolors").value.split("-");
	}
	

	 run() {
		var x = Math.floor(Math.random() * document.getElementById(this.state.canvaName).width); 
		var y = Math.floor(Math.random() * document.getElementById(this.state.canvaName).height);
		var colorAry = this.colorPattern();
		var selectedColor =  Math.floor(Math.random() * colorAry.length);
		this.putCircle(x,y,colorAry[selectedColor]);
	 }
	 
	 putCircle (x,y,color){
		  var canvas = document.getElementById(this.state.canvaName);
		  var context = canvas.getContext('2d');
		  var radius = 10;
		  context.beginPath();
		  context.arc(x, y, radius, 0, 2 * Math.PI, false);
		  context.fillStyle = color;
		  context.fill();
		
	}
	 
	
	render(){
		
		setInterval(
			() => this.run(),
			10
		);
		
		return(
		<div className="component">
			<div className="panel" style={panelStyle}>
				Select colors &nbsp;&nbsp;&nbsp;
				<select id="mycolors">
					<option>yellow-pink-brown</option>
					<option>orange-gray</option>
					<option>red-green-blue</option>
				</select>
			</div>
		
		
			<div>
				<canvas id={this.state.canvaName} style={canvasStyle}>
				</canvas>
			</div>

		</div>
		);
		
	}
}


export default Colp;